import re
from typing import Dict, Optional, Tuple

BUSINESS_PATTERNS = {
    "MOVE": re.compile(r'\bMOVE\s+(?P<src>[^\s]+)\s+TO\s+(?P<tgt>[^\s\.]+)\.', re.IGNORECASE),
    "DERIVED": re.compile(r'\bCOMPUTE\s+(?P<tgt>[^\s=]+)\s*=\s*(?P<expr>[^\.]+)\.', re.IGNORECASE),
    "CONDITIONAL": re.compile(r'\bIF\s+(?P<cond>[^\.]+?)\s+(?:THEN\s+)?(?P<body>.+?)\bEND-IF\.', re.IGNORECASE | re.DOTALL),
    "CALCULATED": re.compile(r'\b(ADD|SUBTRACT|MULTIPLY|DIVIDE)\b.+?\.', re.IGNORECASE | re.DOTALL),
    "STRING_MANIPULATION": re.compile(r'\b(STRING|UNSTRING)\b.+?\.', re.IGNORECASE | re.DOTALL),
}

CICS_PATTERNS = re.compile(r'EXEC\s+CICS\s+(READ|WRITE|SEND|RECEIVE)\b', re.IGNORECASE)

def detect_business_logic(line: str) -> Optional[Tuple[str, Dict]]:
    for k, rx in BUSINESS_PATTERNS.items():
        m = rx.search(line)
        if m:
            return k, m.groupdict()
    return None

def detect_cics(line: str) -> Optional[str]:
    m = CICS_PATTERNS.search(line)
    if m:
        return m.group(1).upper()
    return None

def cobol_pic_to_oracle(pic: str):
    """Rudimentary PIC to Oracle mapping."""
    pic = pic.strip().upper()
    # PIC 9(n)V9(m)
    m = re.match(r'PIC\s+9\((\d+)\)V9\((\d+)\)', pic)
    if m:
        n = int(m.group(1)); mdec = int(m.group(2))
        return ("NUMBER", n+mdec, mdec)

    # PIC 9(n)
    m = re.match(r'PIC\s+9\((\d+)\)', pic)
    if m:
        n = int(m.group(1))
        return ("NUMBER", n, 0)

    # PIC X(n)
    m = re.match(r'PIC\s+X\((\d+)\)', pic)
    if m:
        n = int(m.group(1))
        return ("VARCHAR2", n, None)

    # COMP-3 packed decimal length approximation:
    # number of digits = (bytes*2)-1 if sign, but approximate to NUMBER
    m = re.match(r'PIC\s+S?9\((\d+)\)\s+COMP-3', pic)
    if m:
        n = int(m.group(1))
        return ("NUMBER", n, 0)

    # COMP binary -> NUMBER
    m = re.match(r'PIC\s+S?9\((\d+)\)\s+COMP', pic)
    if m:
        n = int(m.group(1))
        return ("NUMBER", n, 0)

    return ("VARCHAR2", 4000, None)
