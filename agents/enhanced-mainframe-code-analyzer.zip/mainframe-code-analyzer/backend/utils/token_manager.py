import time
import math
import os
from typing import List, Dict, Tuple

MAX_TOKENS_PER_CALL = int(os.getenv("MAX_TOKENS_PER_CALL", "6000"))
EFFECTIVE_CONTENT_LIMIT = int(os.getenv("EFFECTIVE_CONTENT_LIMIT", "5500"))
CHUNK_OVERLAP_TOKENS = int(os.getenv("CHUNK_OVERLAP_TOKENS", "200"))
RATE_LIMIT_DELAY_SEC = 1.0

def estimate_tokens(s: str) -> int:
    # ~4 characters per token approximation
    return math.ceil(len(s) / 4)

def chunk_text_preserving_cobol(source: str) -> List[str]:
    """Chunk text to respect EFFECTIVE_CONTENT_LIMIT with overlap.
    Try to break on COBOL divisions/sections/paragraphs where possible.
    """
    tokens_limit = EFFECTIVE_CONTENT_LIMIT
    overlap = CHUNK_OVERLAP_TOKENS

    # Split by paragraphs and divisions
    import re
    # Keep delimiters in results to preserve structure
    splits = re.split(r'(?=^\s*(IDENTIFICATION|ENVIRONMENT|DATA|PROCEDURE)\s+DIVISION\.|^\s*[A-Z0-9-]+\.)',
                      source, flags=re.MULTILINE)
    if len(splits) <= 1:
        # fallback: split by lines
        lines = source.splitlines(keepends=True)
        chunks = []
        current = []
        current_len = 0
        for ln in lines:
            current.append(ln)
            current_len += estimate_tokens(ln)
            if current_len >= tokens_limit:
                chunks.append(''.join(current))
                # overlap by lines approx tokens->chars
                overlap_chars = overlap * 4
                tail = ''.join(current)[-overlap_chars:]
                current = [tail]
                current_len = estimate_tokens(tail)
        if current:
            chunks.append(''.join(current))
        return chunks

    # Recombine ensuring token budget
    pieces = []
    for i in range(0, len(splits), 2):
        head = splits[i]
        tail = splits[i+1] if i+1 < len(splits) else ""
        pieces.append(head + tail)

    chunks = []
    buf = ""
    for p in pieces:
        if estimate_tokens(buf + p) <= tokens_limit:
            buf += p
        else:
            if buf:
                chunks.append(buf)
                # add overlap from end
                overlap_chars = CHUNK_OVERLAP_TOKENS * 4
                overlap_str = buf[-overlap_chars:] if len(buf) > overlap_chars else buf
                buf = overlap_str + p
                # if too big still, force split
                if estimate_tokens(buf) > tokens_limit:
                    # hard split by chars
                    max_chars = tokens_limit * 4
                    chunks.append(buf[:max_chars])
                    buf = buf[max_chars - overlap_chars:]
            else:
                # single piece too large; hard split
                max_chars = tokens_limit * 4
                chunks.append(p[:max_chars])
                buf = p[max_chars - CHUNK_OVERLAP_TOKENS*4:]
    if buf:
        chunks.append(buf)
    return chunks

def backoff_retry(func, max_attempts=3, base_delay=0.5, *args, **kwargs):
    attempt = 0
    while True:
        try:
            return func(*args, **kwargs)
        except Exception as e:
            attempt += 1
            if attempt >= max_attempts:
                raise
            time.sleep(base_delay * (2 ** (attempt-1)))

def rate_limit_delay():
    time.sleep(RATE_LIMIT_DELAY_SEC)
