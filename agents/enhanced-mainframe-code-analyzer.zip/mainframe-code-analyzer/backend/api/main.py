import os, uuid, json
from fastapi import FastAPI, UploadFile, File, Form
from fastapi.middleware.cors import CORSMiddleware
from typing import List, Optional
from .db import SessionLocal, engine
from .models import AnalysisSession, ComponentAnalysis, FieldMapping, DependencyRelationship, ChatConversation, LlmAnalysisCall, FieldAnalysisDetail
from .create_db import init_db
from .services.analysis_service import AnalysisService

init_db()

app = FastAPI(title="Enhanced Mainframe Code Analyzer", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

svc = AnalysisService()

@app.post("/session/create")
def create_session(project_name: str):
    db = SessionLocal()
    try:
        sid = str(uuid.uuid4())
        rec = AnalysisSession(session_id=sid, project_name=project_name, status="READY")
        db.add(rec); db.commit()
        return {"session_id": sid}
    finally:
        db.close()

@app.get("/session/{session_id}/metrics")
def get_metrics(session_id: str):
    db = SessionLocal()
    try:
        comps = db.query(ComponentAnalysis).filter(ComponentAnalysis.session_id==session_id).all()
        fields = db.query(FieldMapping).filter(FieldMapping.session_id==session_id).count()
        loc = sum(c.total_lines for c in comps)
        size = sum(len(json.dumps(c.analysis_result_json)) for c in comps)
        calls = db.query(LlmAnalysisCall).filter(LlmAnalysisCall.session_id==session_id).all()
        analysis_tokens = sum(c.prompt_tokens + c.response_tokens for c in calls if c.analysis_type!="CHAT")
        chat_tokens = sum(c.prompt_tokens + c.response_tokens for c in calls if c.analysis_type=="CHAT")
        return {
            "components": len(comps),
            "programs": sum(1 for c in comps if c.component_type=="PROGRAM"),
            "copybooks": sum(1 for c in comps if c.component_type=="COPYBOOK"),
            "fields": fields,
            "lines_of_code": loc,
            "total_size": size,
            "tokens": {
                "analysis": analysis_tokens,
                "chat": chat_tokens,
                "total": analysis_tokens + chat_tokens
            }
        }
    finally:
        db.close()

@app.post("/component/analyze")
async def analyze_component(session_id: str = Form(...), component_name: str = Form(...),
                            component_type: str = Form("PROGRAM"), file_path: str = Form(""),
                            content: str = Form(...)):
    comp = {"name": component_name, "type": component_type, "path": file_path, "content": content}
    out = svc.analyze_component(session_id, comp)
    return out

@app.post("/field-mapping/analyze")
async def analyze_field_mapping(session_id: str = Form(...), target_file: str = Form(...), programs_json: str = Form(...)):
    programs = json.loads(programs_json)
    out = svc.field_mapping_analysis(session_id, target_file, programs)
    return out

@app.get("/field-mapping/{session_id}/{target_file}")
def get_field_mapping(session_id: str, target_file: str):
    db = SessionLocal()
    try:
        recs = db.query(FieldMapping).filter(FieldMapping.session_id==session_id, FieldMapping.target_file_name==target_file).all()
        return [{
            "field_name": r.field_name,
            "mainframe_data_type": r.mainframe_data_type,
            "oracle_data_type": r.oracle_data_type,
            "mainframe_length": r.mainframe_length,
            "oracle_length": r.oracle_length,
            "population_source": r.population_source,
            "source_record_layout": r.source_record_layout,
            "business_logic_type": r.business_logic_type,
            "business_logic_description": r.business_logic_description,
            "programs_involved": r.programs_involved_json,
            "confidence_score": r.confidence_score
        } for r in recs]
    finally:
        db.close()
