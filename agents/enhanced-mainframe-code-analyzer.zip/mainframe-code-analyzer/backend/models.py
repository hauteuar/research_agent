from sqlalchemy import Column, Integer, String, DateTime, Boolean, Text, Float
from sqlalchemy import ForeignKey
from sqlalchemy.orm import relationship
from sqlalchemy.types import JSON
from datetime import datetime
from .db import Base

def now():
    return datetime.utcnow()

class AnalysisSession(Base):
    __tablename__ = "analysis_sessions"
    id = Column(Integer, primary_key=True, index=True)
    session_id = Column(String, unique=True, index=True, nullable=False)
    project_name = Column(String, nullable=False)
    created_at = Column(DateTime, default=now)
    status = Column(String, default="READY")  # READY/ANALYZING/ERROR/DONE
    total_components = Column(Integer, default=0)
    total_fields = Column(Integer, default=0)

class LlmAnalysisCall(Base):
    __tablename__ = "llm_analysis_calls"
    id = Column(Integer, primary_key=True, index=True)
    session_id = Column(String, index=True, nullable=False)
    analysis_type = Column(String, index=True, nullable=False)
    chunk_number = Column(Integer, default=1)
    total_chunks = Column(Integer, default=1)
    prompt_tokens = Column(Integer, default=0)
    response_tokens = Column(Integer, default=0)
    processing_time_ms = Column(Integer, default=0)
    success = Column(Boolean, default=True)
    error_message = Column(Text, nullable=True)
    created_at = Column(DateTime, default=now)

class ComponentAnalysis(Base):
    __tablename__ = "component_analysis"
    id = Column(Integer, primary_key=True, index=True)
    session_id = Column(String, index=True, nullable=False)
    component_name = Column(String, index=True)
    component_type = Column(String)  # PROGRAM/COPYBOOK/JCL/PROC
    file_path = Column(String)
    analysis_status = Column(String, default="PENDING")  # PENDING/DONE/ERROR
    total_lines = Column(Integer, default=0)
    total_fields = Column(Integer, default=0)
    dependencies_count = Column(Integer, default=0)
    analysis_result_json = Column(JSON, default={})
    created_at = Column(DateTime, default=now)
    updated_at = Column(DateTime, default=now)

class FieldMapping(Base):
    __tablename__ = "field_mappings"
    id = Column(Integer, primary_key=True, index=True)
    session_id = Column(String, index=True, nullable=False)
    target_file_name = Column(String, index=True, nullable=False)
    field_name = Column(String, nullable=False)
    mainframe_data_type = Column(String, nullable=True)
    oracle_data_type = Column(String, nullable=True)
    mainframe_length = Column(Integer, nullable=True)
    oracle_length = Column(Integer, nullable=True)
    population_source = Column(String, nullable=True)
    source_record_layout = Column(String, nullable=True)
    business_logic_type = Column(String, nullable=True)  # MOVE/DERIVED/...
    business_logic_description = Column(Text, nullable=True)
    derivation_logic = Column(Text, nullable=True)
    programs_involved_json = Column(JSON, default=[])
    confidence_score = Column(Float, default=0.0)
    analysis_timestamp = Column(DateTime, default=now)

class DependencyRelationship(Base):
    __tablename__ = "dependency_relationships"
    id = Column(Integer, primary_key=True, index=True)
    session_id = Column(String, index=True, nullable=False)
    source_component = Column(String, index=True)
    target_component = Column(String, index=True)
    relationship_type = Column(String)  # CALLS/READS/WRITES/INCLUDES
    interface_type = Column(String)     # FILE/DB2/CICS/CALL/COPY
    confidence_score = Column(Float, default=0.0)
    analysis_details_json = Column(JSON, default={})
    created_at = Column(DateTime, default=now)

class ChatConversation(Base):
    __tablename__ = "chat_conversations"
    id = Column(Integer, primary_key=True, index=True)
    session_id = Column(String, index=True, nullable=False)
    conversation_id = Column(String, index=True, nullable=False)
    message_type = Column(String)  # USER/ASSISTANT/SYSTEM
    message_content = Column(Text)
    context_used_json = Column(JSON, default={})
    tokens_used = Column(Integer, default=0)
    processing_time_ms = Column(Integer, default=0)
    created_at = Column(DateTime, default=now)

class FieldAnalysisDetail(Base):
    __tablename__ = "field_analysis_details"
    id = Column(Integer, primary_key=True, index=True)
    session_id = Column(String, index=True, nullable=False)
    field_id = Column(String, index=True)
    program_name = Column(String, index=True)
    operation_type = Column(String)  # MOVE/COMPUTE/READ/WRITE/STRING/IF/etc.
    line_number = Column(Integer, default=0)
    code_snippet = Column(Text)
    analysis_confidence = Column(Float, default=0.0)
    created_at = Column(DateTime, default=now)
