from typing import Dict, Any, List
from ..llm.manager import LlmManager
from ..utils.cobol_utils import detect_business_logic, detect_cics, cobol_pic_to_oracle
from ..db import SessionLocal
from ..models import ComponentAnalysis, FieldMapping, FieldAnalysisDetail, DependencyRelationship
import re, json, time

class AnalysisService:
    def __init__(self):
        self.llm = LlmManager()

    def analyze_component(self, session_id: str, component: Dict[str, Any]) -> Dict[str, Any]:
        """Analyze a single component (program/copybook/jcl/proc)."""
        db = SessionLocal()
        try:
            text = component.get("content", "")
            lines = text.splitlines()
            total_lines = len(lines)

            # quick parse: dependencies and operations
            deps = []
            field_details = []
            fields_seen = set()

            for idx, ln in enumerate(lines, start=1):
                cics_op = detect_cics(ln)
                if cics_op:
                    deps.append({"type": "CICS", "op": cics_op, "line": idx})

                biz = detect_business_logic(ln)
                if biz:
                    btype, meta = biz
                    field_details.append({
                        "operation_type": btype,
                        "line_number": idx,
                        "code_snippet": ln.strip()
                    })

                # naive COBOL field definition detection: 05 FIELD-NAME PIC X(10).
                m = re.search(r'\b\d{2}\s+([A-Z0-9-]+)\s+PIC\s+([^\.]+)\.', ln, re.IGNORECASE)
                if m:
                    fields_seen.add(m.group(1))

            # LLM assisted structured analysis (stub)
            llm_out = self.llm.analyze_large_text(session_id, "COMPONENT", text)

            # Store component_analysis
            ca = ComponentAnalysis(
                session_id=session_id,
                component_name=component.get("name"),
                component_type=component.get("type","PROGRAM"),
                file_path=component.get("path",""),
                analysis_status="DONE",
                total_lines=total_lines,
                total_fields=len(fields_seen),
                dependencies_count=len(deps),
                analysis_result_json={"deps": deps, "llm": llm_out}
            )
            db.add(ca)
            db.commit()

            # Store dependency details
            for d in deps:
                dr = DependencyRelationship(
                    session_id=session_id,
                    source_component=component.get("name"),
                    target_component=f"CICS:{d['op']}",
                    relationship_type="CICS",
                    interface_type="CICS",
                    confidence_score=0.7,
                    analysis_details_json=d
                )
                db.add(dr)

            # Store field analysis details
            for fd in field_details:
                fad = FieldAnalysisDetail(
                    session_id=session_id,
                    field_id="",  # could resolve later via mapping
                    program_name=component.get("name"),
                    operation_type=fd["operation_type"],
                    line_number=fd["line_number"],
                    code_snippet=fd["code_snippet"],
                    analysis_confidence=0.6
                )
                db.add(fad)

            db.commit()
            return {"status": "ok", "component": component.get("name"), "fields": list(fields_seen)}
        finally:
            db.close()

    def field_mapping_analysis(self, session_id: str, target_file: str, programs: List[Dict[str,Any]]):
        """Analyze all programs writing to a target file and build field mappings."""
        db = SessionLocal()
        mappings = []
        try:
            for p in programs:
                content = p.get("content","")
                name = p.get("name","")
                lines = content.splitlines()
                for idx, ln in enumerate(lines, start=1):
                    # Detect writes to the target file (simplified)
                    if re.search(rf'\bWRITE\s+{re.escape(target_file)}\b', ln, re.IGNORECASE) or                        re.search(rf'\bMOVE\s+.+\s+TO\s+{re.escape(target_file)}-([A-Z0-9-]+)', ln, re.IGNORECASE):
                        # Extract target field name if present
                        m = re.search(rf'{re.escape(target_file)}-([A-Z0-9-]+)', ln, re.IGNORECASE)
                        tgt_field = m.group(1) if m else None

                        biz = detect_business_logic(ln)
                        btype = None; bdesc = None; deriv = None
                        if biz:
                            btype, meta = biz
                            bdesc = str(meta)
                            if btype == "DERIVED":
                                deriv = meta.get("expr")

                        # naive find PIC line near definition (search backwards)
                        pic = None
                        for j in range(max(0, idx-10), min(len(lines), idx+10)):
                            mm = re.search(rf'\b{re.escape(target_file)}-{tgt_field}\b.*PIC\s+([^\.]+)\.', lines[j], re.IGNORECASE) if tgt_field else None
                            if mm:
                                pic = "PIC " + mm.group(1)
                                break

                        ora_type, ora_len, ora_scale = cobol_pic_to_oracle(pic) if pic else ("VARCHAR2", 4000, None)

                        mapping = FieldMapping(
                            session_id=session_id,
                            target_file_name=target_file,
                            field_name=tgt_field or "UNKNOWN",
                            mainframe_data_type=pic or "",
                            oracle_data_type=f"{ora_type}",
                            mainframe_length=None,
                            oracle_length=ora_len if ora_len else None,
                            population_source="MOVE/WRITE",
                            source_record_layout="",
                            business_logic_type=btype or "MOVE",
                            business_logic_description=bdesc or "",
                            derivation_logic=deriv or "",
                            programs_involved_json=[name],
                            confidence_score=0.7
                        )
                        db.add(mapping)
                        db.commit()
                        mappings.append(mapping.id)

            return {"status":"ok", "count": len(mappings)}
        finally:
            db.close()
