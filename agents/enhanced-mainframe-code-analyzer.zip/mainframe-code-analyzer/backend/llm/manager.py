import os, time
from typing import Dict, List, Any
from ..utils.token_manager import estimate_tokens, chunk_text_preserving_cobol, backoff_retry, rate_limit_delay, MAX_TOKENS_PER_CALL, EFFECTIVE_CONTENT_LIMIT
from ..db import SessionLocal
from ..models import LlmAnalysisCall
import uuid

class LlmManager:
    def __init__(self):
        self.provider = os.getenv("LLM_PROVIDER", "stub")
        self.model = os.getenv("LLM_MODEL", "gpt-5-thinking")

    def _call_llm(self, prompt: str) -> Dict[str, Any]:
        # STUB: Replace with real provider call
        # Return JSON-like dict with minimal structure and token counts
        resp_text = "{\"summary\": \"stub analysis\", \"entities\": []}"
        return {
            "text": resp_text,
            "prompt_tokens": estimate_tokens(prompt),
            "response_tokens": estimate_tokens(resp_text)
        }

    def analyze_large_text(self, session_id: str, analysis_type: str, content: str) -> Dict[str, Any]:
        chunks = chunk_text_preserving_cobol(content)
        total_chunks = len(chunks)
        results: List[Dict[str, Any]] = []
        db = SessionLocal()
        try:
            for i, ch in enumerate(chunks, start=1):
                prompt = f"[ANALYSIS_TYPE={analysis_type}]\nCHUNK {i}/{total_chunks}\n\n{ch}"
                def one_call():
                    start = time.time()
                    out = self._call_llm(prompt)
                    elapsed_ms = int((time.time() - start)*1000)
                    rec = LlmAnalysisCall(
                        session_id=session_id,
                        analysis_type=analysis_type,
                        chunk_number=i,
                        total_chunks=total_chunks,
                        prompt_tokens=out["prompt_tokens"],
                        response_tokens=out["response_tokens"],
                        processing_time_ms=elapsed_ms,
                        success=True
                    )
                    db.add(rec)
                    db.commit()
                    return out
                try:
                    out = backoff_retry(one_call, max_attempts=3)
                    results.append(out)
                except Exception as e:
                    rec = LlmAnalysisCall(
                        session_id=session_id,
                        analysis_type=analysis_type,
                        chunk_number=i,
                        total_chunks=total_chunks,
                        prompt_tokens=estimate_tokens(prompt),
                        response_tokens=0,
                        processing_time_ms=0,
                        success=False,
                        error_message=str(e)
                    )
                    db.add(rec)
                    db.commit()
                rate_limit_delay()
        finally:
            db.close()

        # Consolidation (simple merge; in real case, resolve conflicts by confidence/type)
        combined_texts = [r["text"] for r in results if "text" in r]
        return {"combined_text": "\n".join(combined_texts), "chunks": total_chunks}
