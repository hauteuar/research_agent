import React, { useEffect, useState, useMemo } from 'react'
import { createRoot } from 'react-dom/client'

const API = (path) => `http://localhost:8000${path}`

function Header({metrics, status, chunkProgress}){
  return (
    <div className="header">
      <div className="row">
        <strong>Enhanced Mainframe Analyzer</strong>
        <span className="status">{status} {chunkProgress ? `• ${chunkProgress}` : ''}</span>
      </div>
      <div className="metrics">
        <span>Components: <b>{metrics.components}</b></span>
        <span>Programs: <b>{metrics.programs}</b></span>
        <span>Copybooks: <b>{metrics.copybooks}</b></span>
        <span>Fields: <b>{metrics.fields}</b></span>
        <span>LoC: <b>{metrics.lines_of_code}</b></span>
        <span>Total Size: <b>{metrics.total_size}</b></span>
        <span className="token-usage">Tokens A:{metrics.tokens.analysis} C:{metrics.tokens.chat} T:{metrics.tokens.total}</span>
      </div>
    </div>
  )
}

function LeftPanel({sessionId, metrics}){
  const [name, setName] = useState('')
  const [content, setContent] = useState('')
  const [componentName, setComponentName] = useState('PROGRAM1')
  const [componentType, setComponentType] = useState('PROGRAM')

  async function analyze(){
    const fm = new FormData()
    fm.append('session_id', sessionId)
    fm.append('component_name', componentName)
    fm.append('component_type', componentType)
    fm.append('file_path', '/tmp/dummy.cbl')
    fm.append('content', content)
    await fetch(API('/component/analyze'), { method:'POST', body: fm })
  }

  return (
    <div className="panel">
      <h3>Component Dashboard</h3>
      <div className="content">
        <div className="row">
          <input placeholder="Component Name" value={componentName} onChange={(e)=>setComponentName(e.target.value)} />
          <select value={componentType} onChange={(e)=>setComponentType(e.target.value)}>
            <option>PROGRAM</option><option>COPYBOOK</option><option>JCL</option><option>PROC</option>
          </select>
        </div>
        <div style={{marginTop:8}}>
          <textarea placeholder="Paste COBOL/JCL here..." value={content} onChange={e=>setContent(e.target.value)} />
        </div>
        <div className="row" style={{marginTop:8}}>
          <button onClick={analyze}>Analyze Component</button>
        </div>

        <h3 style={{marginTop:16}}>Token Usage</h3>
        <div className="content">
          <div className="row">
            <span className="pill">Max/Call: 6000</span>
            <span className="pill">Content Limit: 5500</span>
            <span className="pill">Overlap: 200</span>
            <span className="pill">Rate: 1s/chunk</span>
          </div>
        </div>
      </div>
    </div>
  )
}

function Tabs({active, setActive}){
  const tabs = ['Dashboard','Components Library','Dependencies Flow','Field Matrix','Field Mapping Analysis']
  return (
    <div className="tabs">
      {tabs.map(t => (
        <div key={t} className={"tab " + (active===t?'active':'')} onClick={()=>setActive(t)}>{t}</div>
      ))}
    </div>
  )
}

function FieldMappingTab({sessionId}){
  const [file, setFile] = useState('CUSTOMER-FILE')
  const [programs, setPrograms] = useState([
    {name:'PROGRAM1', content:'MOVE CUST-NAME TO CUSTOMER-FILE-NAME. WRITE CUSTOMER-FILE.'}
  ])
  const [rows, setRows] = useState([])

  async function analyze(){
    const fm = new FormData()
    fm.append('session_id', sessionId)
    fm.append('target_file', file)
    fm.append('programs_json', JSON.stringify(programs))
    await fetch(API('/field-mapping/analyze'), { method:'POST', body: fm })
    const out = await (await fetch(API(`/field-mapping/${sessionId}/${file}`))).json()
    setRows(out)
  }

  return (
    <div className="content">
      <div className="row">
        <input type="text" placeholder="Enter file name (e.g., CUSTOMER-FILE)" value={file} onChange={e=>setFile(e.target.value)} />
        <button onClick={analyze}>🔍 Analyze Field Mapping</button>
      </div>
      <table className="advanced-mapping-table" style={{marginTop:12}}>
        <thead>
          <tr>
            <th>Field Name</th><th>Mainframe Data Type</th><th>Oracle Data Type</th>
            <th>MF Length</th><th>Oracle Length</th><th>Population Source</th>
            <th>Source Record Layout</th><th>Business Logic</th><th>Programs Involved</th>
          </tr>
        </thead>
        <tbody>
          {rows.map((r,idx)=>(
            <tr key={idx}>
              <td>{r.field_name}</td>
              <td>{r.mainframe_data_type}</td>
              <td>{r.oracle_data_type}</td>
              <td>{r.mainframe_length||''}</td>
              <td>{r.oracle_length||''}</td>
              <td>{r.population_source}</td>
              <td>{r.source_record_layout}</td>
              <td><span className="badge">{r.business_logic_type}</span> {r.business_logic_description}</td>
              <td>{(r.programs_involved||[]).join(', ')}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}

function RightChat({sessionId}){
  const [messages, setMessages] = useState([])
  const [input, setInput] = useState('')
  const tokens = useMemo(()=>{
    const chars = input.length
    return Math.ceil(chars/4)
  }, [input])

  function send(){
    setMessages(m => [...m, {role:'user', content: input, tokens}])
    setInput('')
  }

  return (
    <div className="panel right chat">
      <h3>Business Intelligence Chat</h3>
      <div className="chat-messages">
        {messages.map((m,i)=>(
          <div key={i} style={{margin:'8px 0'}}>
            <div className="badge">{m.role.toUpperCase()} • {m.tokens} tok</div>
            <div>{m.content}</div>
          </div>
        ))}
      </div>
      <div className="chat-input">
        <textarea value={input} onChange={e=>setInput(e.target.value)} placeholder="Ask about fields, components, dependencies..." />
        <div style={{display:'flex', flexDirection:'column', gap:6}}>
          <div className="pill" title="Approx tokens for this message">~{tokens} tok</div>
          <button onClick={send}>Send</button>
        </div>
      </div>
    </div>
  )
}

function App(){
  const [sessionId, setSessionId] = useState(null)
  const [metrics, setMetrics] = useState({components:0, programs:0, copybooks:0, fields:0, lines_of_code:0, total_size:0, tokens:{analysis:0, chat:0, total:0}})
  const [status, setStatus] = useState('Ready')
  const [active, setActive] = useState('Dashboard')

  useEffect(()=>{
    ;(async()=>{
      const res = await fetch(API('/session/create?project_name=Demo Project'), { method:'POST'})
      const js = await res.json()
      setSessionId(js.session_id)
    })()
  }, [])

  useEffect(()=>{
    if(!sessionId) return
    const t = setInterval(async ()=>{
      const m = await (await fetch(API(`/session/${sessionId}/metrics`))).json()
      setMetrics(m)
    }, 1500)
    return ()=>clearInterval(t)
  }, [sessionId])

  return (
    <div>
      <Header metrics={metrics} status={status} chunkProgress={null} />
      <div className="layout">
        <LeftPanel sessionId={sessionId} metrics={metrics} />
        <div className="panel">
          <Tabs active={active} setActive={setActive} />
          {active==='Dashboard' && <div className="content">
            <p>Welcome! Use the left panel to upload components and run analysis. Check other tabs for dependencies, field matrix, and the star ⭐ Field Mapping Analysis.</p>
          </div>}
          {active==='Field Mapping Analysis' && <FieldMappingTab sessionId={sessionId} />}
          {active!=='Field Mapping Analysis' && active!=='Dashboard' && <div className="content">Coming soon.</div>}
        </div>
        <RightChat sessionId={sessionId} />
      </div>
    </div>
  )
}

createRoot(document.getElementById('root')).render(<App />)
