# Enhanced Mainframe Code Analyzer

Full-stack skeleton implementing:
- Token-aware chunking (6000 max, 5500 effective, 200 overlap, 1s rate limit, retry with backoff)
- SQL persistence for sessions, LLM calls, components, dependencies, field mappings, chat, field analysis details
- Field Mapping Analysis tab with business logic patterns and COBOL PIC → Oracle mapping
- Three-panel UI with header metrics and token counters

## Run Backend
```bash
cd backend
python -m venv .venv && source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -r requirements.txt
python -m api.main  # or: python run.py
```
Backend default: http://localhost:8000

## Run Frontend
```bash
cd frontend
npm i
npm run dev
```
Frontend default: http://localhost:5173

## Key Config
- MAX_TOKENS_PER_CALL=6000
- EFFECTIVE_CONTENT_LIMIT=5500
- CHUNK_OVERLAP_TOKENS=200

## Notes
- LLM calls are stubbed in `backend/llm/manager.py`. Replace `_call_llm` with your provider logic.
- Chunking tries to respect COBOL structure. Fallback to line-based if divisions/paragraphs can't be found.
- Field mapping logic demonstrates required patterns and PIC→Oracle mapping rules.
- All outputs stored to SQLite (analysis.db). Change `DATABASE_URL` to use Postgres/MySQL if needed.

## Exports (future hooks)
- Add routes to create CSV/JSON/Excel using pandas/xlsxwriter from FieldMapping and ComponentAnalysis tables.
